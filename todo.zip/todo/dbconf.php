<?php $db = 'mysql:host=localhost;dbname=todo;charset=utf8';
$pdo = new PDO($db, 'admin', 'madmidnight'); ?>